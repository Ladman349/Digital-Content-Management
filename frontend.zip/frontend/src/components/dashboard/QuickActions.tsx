import {
  Box,
  Button,
  Stack,
  Typography,
} from "@mui/material";

import DashboardCard from "../common/DashboardCard";

export default function QuickActions() {
  const actions = [
    "➕ Add Device",
    "📤 Upload Media",
    "📅 Create Schedule",
    "▶ Create Playlist",
  ];

  return (
    <DashboardCard>
      <Typography
        variant="h6"
        sx={{
          fontWeight: 700,
          mb: 3,
        }}
      >
        Quick Actions
      </Typography>

      <Stack spacing={2}>
        {actions.map((action) => (
          <Button
            key={action}
            fullWidth
            variant="outlined"
            sx={{
              justifyContent: "flex-start",
              borderRadius: 3,
              py: 1.5,
              textTransform: "none",
              fontWeight: 600,
            }}
          >
            {action}
          </Button>
        ))}
      </Stack>

      <Box
        sx={{
          mt: 3,
          p: 2,
          borderRadius: 3,
          bgcolor: "#F8FAFC",
        }}
      >
        <Typography
          sx={{
            fontWeight: 600,
          }}
        >
          💡 Tip
        </Typography>

        <Typography
          sx={{
            mt: 1,
            color: "text.secondary",
            fontSize: 14,
          }}
        >
          Schedule your playlists in advance to automate content across all displays.
        </Typography>
      </Box>
    </DashboardCard>
  );
}