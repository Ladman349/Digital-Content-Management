import {
  Box,
  Typography,
  ToggleButton,
  ToggleButtonGroup,
} from "@mui/material";
import { useState } from "react";

import DashboardCard from "../common/DashboardCard";

import {
  Area,
  AreaChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";

const data = [
  { day: "Mon", plays: 250 },
  { day: "Tue", plays: 410 },
  { day: "Wed", plays: 320 },
  { day: "Thu", plays: 580 },
  { day: "Fri", plays: 670 },
  { day: "Sat", plays: 620 },
  { day: "Sun", plays: 810 },
];

export default function ActivityChart() {
  const [range, setRange] = useState("7");

  return (
    <DashboardCard>
      <Box
        sx={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          mb: 3,
        }}
      >
        <Box>
          <Typography
            variant="h6"
            sx={{
              fontWeight: 700,
            }}
          >
            Playback Activity
          </Typography>

          <Typography color="text.secondary">
            Advertisement plays over time
          </Typography>
        </Box>

        <ToggleButtonGroup
          size="small"
          value={range}
          exclusive
          onChange={(_, value) => value && setRange(value)}
        >
          <ToggleButton value="7">7D</ToggleButton>
          <ToggleButton value="30">30D</ToggleButton>
          <ToggleButton value="90">90D</ToggleButton>
        </ToggleButtonGroup>
      </Box>

      <Box sx={{ height: 340 }}>
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data}>
            <defs>
              <linearGradient id="plays" x1="0" y1="0" x2="0" y2="1">
                <stop
                  offset="0%"
                  stopColor="#6C4CF1"
                  stopOpacity={0.35}
                />
                <stop
                  offset="100%"
                  stopColor="#6C4CF1"
                  stopOpacity={0}
                />
              </linearGradient>
            </defs>

            <CartesianGrid
              strokeDasharray="4 4"
              vertical={false}
            />

            <XAxis
              dataKey="day"
              tickLine={false}
              axisLine={false}
            />

            <YAxis
              tickLine={false}
              axisLine={false}
            />

            <Tooltip />

            <Area
              type="monotone"
              dataKey="plays"
              stroke="#6C4CF1"
              strokeWidth={4}
              fill="url(#plays)"
            />
          </AreaChart>
        </ResponsiveContainer>
      </Box>
    </DashboardCard>
  );
}