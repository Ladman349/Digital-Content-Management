import { Box, Button, Typography } from "@mui/material";
import DownloadRoundedIcon from "@mui/icons-material/DownloadRounded";

export default function DashboardHeader() {
  return (
    <Box
      sx={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        mb: 4,
      }}
    >
      <Box>
        <Typography
          variant="h4"
          sx={{
            fontWeight: 700,
          }}
        >
          Dashboard 👋
        </Typography>

        <Typography
          sx={{
            color: "#6B7280",
            mt: 1,
          }}
        >
          Welcome back, Akash. Here's what's happening across your signage network.
        </Typography>
      </Box>

      <Button
        variant="contained"
        startIcon={<DownloadRoundedIcon />}
        sx={{
          height: 48,
          borderRadius: 3,
          px: 3,
        }}
      >
        Export Report
      </Button>
    </Box>
  );
}