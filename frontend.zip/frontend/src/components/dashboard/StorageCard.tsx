import {
  Box,
  Button,
  CircularProgress,
  Typography,
} from "@mui/material";

import DashboardCard from "../common/DashboardCard";

export default function StorageCard() {
  const used = 62;

  return (
    <DashboardCard>
      <Typography
        variant="h6"
        sx={{
          fontWeight: 700,
          mb: 3,
        }}
      >
        Storage Usage
      </Typography>
<Box
  sx={{
    display: "flex",
    flexDirection: "column",
    gap: 3,
    alignItems: "center",
  }}
>
        <Box
          sx={{
            position: "relative",
            display: "inline-flex",
          }}
        >
          <CircularProgress
            variant="determinate"
            value={100}
            size={160}
            thickness={4}
            sx={{
              color: "#E5E7EB",
            }}
          />

          <CircularProgress
            variant="determinate"
            value={used}
            size={160}
            thickness={4}
            sx={{
              color: "#6C4CF1",
              position: "absolute",
              left: 0,
            }}
          />

          <Box
            sx={{
              position: "absolute",
              inset: 0,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              flexDirection: "column",
            }}
          >
            <Typography
              variant="h4"
              sx={{
                fontWeight: 700,
              }}
            >
              {used}%
            </Typography>

            <Typography
              sx={{
                color: "text.secondary",
              }}
            >
              Used
            </Typography>
          </Box>
        </Box>

        <Box
          sx={{
            width: "100%",
          }}
        >
          <Typography
            sx={{
              display: "flex",
              justifyContent: "space-between",
              mb: 1,
            }}
          >
            <span>Storage Used</span>
            <strong>62.4 GB / 100 GB</strong>
          </Typography>

          <Typography
            sx={{
              display: "flex",
              justifyContent: "space-between",
              mb: 3,
            }}
          >
            <span>Media Files</span>
            <strong>1,245 Files</strong>
          </Typography>

          <Button
            fullWidth
            variant="contained"
            sx={{
              borderRadius: 3,
              py: 1.5,
              textTransform: "none",
              background:
                "linear-gradient(135deg,#6C4CF1,#8B5CF6)",
            }}
          >
            Manage Storage
          </Button>
        </Box>
      </Box>
    </DashboardCard>
  );
}