import {
  Avatar,
  Box,
  Chip,
  Divider,
  Stack,
  Typography,
} from "@mui/material";

import DashboardCard from "../common/DashboardCard";

const playlists = [
  {
    name: "Morning Ads",
    screens: "12 Screens",
    status: "Active",
    image: "🌅",
  },
  {
    name: "Weekend Offers",
    screens: "8 Screens",
    status: "Active",
    image: "🛍️",
  },
  {
    name: "Festival Campaign",
    screens: "5 Screens",
    status: "Inactive",
    image: "🎉",
  },
];

export default function RecentPlaylists() {
  return (
    <DashboardCard>
      <Typography
        variant="h6"
        sx={{
          fontWeight: 700,
          mb: 3,
        }}
      >
        Recent Playlists
      </Typography>

      <Stack spacing={2}>
        {playlists.map((playlist, index) => (
          <Box key={playlist.name}>
            <Box
              sx={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
              }}
            >
              <Box
                sx={{
                  display: "flex",
                  gap: 2,
                  alignItems: "center",
                }}
              >
                <Avatar
                  variant="rounded"
                  sx={{
                    width: 56,
                    height: 56,
                    bgcolor: "#EEF2FF",
                    fontSize: 28,
                  }}
                >
                  {playlist.image}
                </Avatar>

                <Box>
                  <Typography
                    sx={{
                      fontWeight: 600,
                    }}
                  >
                    {playlist.name}
                  </Typography>

                  <Typography
                    sx={{
                      color: "text.secondary",
                      fontSize: 13,
                    }}
                  >
                    {playlist.screens}
                  </Typography>
                </Box>
              </Box>

              <Chip
                label={playlist.status}
                color={
                  playlist.status === "Active"
                    ? "success"
                    : "default"
                }
              />
            </Box>

            {index !== playlists.length - 1 && (
              <Divider sx={{ mt: 2 }} />
            )}
          </Box>
        ))}
      </Stack>
    </DashboardCard>
  );
}