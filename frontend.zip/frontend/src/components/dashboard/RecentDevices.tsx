import {
  Avatar,
  Box,
  Chip,
  Divider,
  Stack,
  Typography,
} from "@mui/material";

import DashboardCard from "../common/DashboardCard";

const devices = [
  {
    name: "Lobby Display",
    location: "Reception",
    status: "Online",
  },
  {
    name: "Store TV",
    location: "Floor 1",
    status: "Online",
  },
  {
    name: "Meeting Room",
    location: "Conference",
    status: "Offline",
  },
];

export default function RecentDevices() {
  return (
    <DashboardCard>
      <Typography
        variant="h6"
        sx={{
          fontWeight: 700,
          mb: 3,
        }}
      >
        Recent Devices
      </Typography>

      <Stack spacing={2}>
        {devices.map((device, index) => (
          <Box key={device.name}>
            <Box
              sx={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
              }}
            >
              <Box
                sx={{
                  display: "flex",
                  gap: 2,
                  alignItems: "center",
                }}
              >
                <Avatar
                  sx={{
                    bgcolor: "#EEF2FF",
                    color: "#6C4CF1",
                  }}
                >
                    📺
                </Avatar>

                <Box>
                  <Typography
                    sx={{
                      fontWeight: 600,
                    }}
                  >
                    {device.name}
                  </Typography>

                  <Typography
                    sx={{
                      color: "text.secondary",
                      fontSize: 13,
                    }}
                  >
                    {device.location}
                  </Typography>
                </Box>
              </Box>

              <Chip
                label={device.status}
                color={
                  device.status === "Online"
                    ? "success"
                    : "error"
                }
              />
            </Box>

            {index !== devices.length - 1 && (
              <Divider sx={{ mt: 2 }} />
            )}
          </Box>
        ))}
      </Stack>
    </DashboardCard>
  );
}