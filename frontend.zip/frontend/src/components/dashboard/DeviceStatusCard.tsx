import {
  Box,
  Typography,
} from "@mui/material";

import DashboardCard from "../common/DashboardCard";

import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
} from "recharts";

const data = [
  {
    name: "Online",
    value: 96,
    color: "#22C55E",
  },
  {
    name: "Idle",
    value: 18,
    color: "#F59E0B",
  },
  {
    name: "Offline",
    value: 14,
    color: "#EF4444",
  },
];

export default function DeviceStatusCard() {
  return (
    <DashboardCard>
      <Typography
        variant="h6"
        sx={{
          fontWeight: 700,
          mb: 3,
        }}
      >
        Device Status
      </Typography>

      <Box
        sx={{
          width: "100%",
          height: 260,
        }}
      >
        <ResponsiveContainer>
          <PieChart>
            <Pie
              data={data}
              innerRadius={70}
              outerRadius={92}
              dataKey="value"
              paddingAngle={4}
            >
              {data.map((item) => (
                <Cell
                  key={item.name}
                  fill={item.color}
                />
              ))}
            </Pie>

            <text
              x="50%"
              y="48%"
              textAnchor="middle"
              dominantBaseline="middle"
              fontSize="30"
              fontWeight="700"
            >
              128
            </text>

            <text
              x="50%"
              y="60%"
              textAnchor="middle"
              dominantBaseline="middle"
              fontSize="14"
              fill="#64748B"
            >
              Devices
            </text>
          </PieChart>
        </ResponsiveContainer>
      </Box>

      {data.map((item) => (
        <Box
          key={item.name}
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            mt: 2,
          }}
        >
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              gap: 1.5,
            }}
          >
            <Box
              sx={{
                width: 12,
                height: 12,
                borderRadius: "50%",
                bgcolor: item.color,
              }}
            />

            <Typography>
              {item.name}
            </Typography>
          </Box>

          <Typography
            sx={{
              fontWeight: 700,
            }}
          >
            {item.value}
          </Typography>
        </Box>
      ))}
    </DashboardCard>
  );
}