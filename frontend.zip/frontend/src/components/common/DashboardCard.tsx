import { Paper } from "@mui/material";
import type { ReactNode } from "react";

interface Props {
  children: ReactNode;
}

export default function DashboardCard({ children }: Props) {
  return (
    <Paper
      elevation={0}
      sx={{
        borderRadius: 5,
        p: 3,
        background: "#fff",
        border: "1px solid #EEF2F7",
        boxShadow: "0 10px 35px rgba(15,23,42,.05)",
        transition: ".25s",

        "&:hover": {
          transform: "translateY(-4px)",
          boxShadow: "0 20px 50px rgba(15,23,42,.10)",
        },
      }}
    >
      {children}
    </Paper>
  );
}