import Grid from "@mui/material/Grid";

import DashboardHeader from "../../components/dashboard/DashboardHeader";
import StatsGrid from "../../components/dashboard/StatsGrid";
import ActivityChart from "../../components/dashboard/ActivityChart";
import DeviceStatusCard from "../../components/dashboard/DeviceStatusCard";
import RecentDevices from "../../components/dashboard/RecentDevices";
import RecentPlaylists from "../../components/dashboard/RecentPlaylists";
import StorageCard from "../../components/dashboard/StorageCard";
import QuickActions from "../../components/dashboard/QuickActions";

export default function DashboardPage() {
  return (
    <>
      <DashboardHeader />

      <StatsGrid />

      <Grid
        container
        spacing={3}
        sx={{ mt: 1 }}
      >
        <Grid sx={{ flex: "1 1 65%", minWidth: 600 }}>
          <ActivityChart />
        </Grid>

        <Grid sx={{ flex: "1 1 30%", minWidth: 320 }}>
          <DeviceStatusCard />
        </Grid>

        <Grid sx={{ flex: "1 1 48%", minWidth: 420 }}>
          <RecentDevices />
        </Grid>

        <Grid sx={{ flex: "1 1 48%", minWidth: 420 }}>
          <RecentPlaylists />
        </Grid>

        <Grid sx={{ flex: "1 1 48%", minWidth: 420 }}>
          <StorageCard />
        </Grid>

        <Grid sx={{ flex: "1 1 48%", minWidth: 420 }}>
          <QuickActions />
        </Grid>
      </Grid>
    </>
  );
}